/*
 * rockProperties.cpp
 *
 *  Created on: Oct 26, 2014
 *      Author: rogerio
 */


#include "rockProp.h"

//void getRockPropertyFuncPointer(RockPropFuncPointer* pFunc){
//
//#ifdef CASE_Homogeneous2D
//	return Homogeneous2D;
//#endif
//
//}
//
//void Homogeneous2D(pEntity e, double* K){
//	K[0] = 1.0; K[1] = 0.0;
//	K[2] = 0.0; K[3] = 1.0;
//}

