PADMEC_AMR: ADAPTATIVE MESH REFINEMENT FOR TWO-PHASE OIL-WATER SIMULATION IN POROUS MEDIA

-------------------------------------------------------------------------------------
UNIVERSIDADE FEDERAL DE PERNAMBUCO - UFPE
CENTRO DE TECNOLOGIA E GEOCIENCIAS - CTG
CENTRO ACADEMICO DO AGRESTE - CAA
PROCESSAMENTO DE ALTO DESEMPENHO DA MECANICA COMPUATCIONAL - PADMEC
-------------------------------------------------------------------------------------

Este projeto � desenvolvido  e coordenado por:
Prof. Rog�rio Soares 	(CAA)
Prof. Paulo Lyra		(CTG)

Equipe:
-------------------------------------------------------------------------------------
Erika Oliveira da Silva		(Adaptacao h)
Saulo Rantz					(Remeshing)
Brunno Correia da Silva		(Remeshing)
Gulherme					(Remeshing)

