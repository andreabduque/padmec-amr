/*
 * interpolation.cpp
 *
 *  Created on: Dec 6, 2013
 *      Author: rogerio
 */

 /*Added Conservative Interpolation by Andrea*/

#include "interpolation.h"

void interpolation(InterpolationDataStruct* pIData, INTERPOLATION_OPTIONS opt){
	initialize(pIData);
	int dim = pIData->m1->getDim();
	switch ( opt ){
	case h_REFINEMENT:
		throw Exception(__LINE__,__FILE__,"Underconstruction!");
		break;
	case LINEAR:
		#ifdef TRACKING_PROGRAM_STEPS
		cout << "TRACKING_PROGRAM_STEPS: Interpolation (Linear Method)\tIN\n";
		#endif
		calculate_GeometricCoefficients(pIData,dim);
		calculate_LinearInterpolation(pIData,dim);
		#ifdef TRACKING_PROGRAM_STEPS
		cout << "TRACKING_PROGRAM_STEPS: Interpolation (Linear Method)\tOUT\n";
		#endif
		break;
	case QUADRATIC:
		#ifdef TRACKING_PROGRAM_STEPS
		cout << "TRACKING_PROGRAM_STEPS: Interpolation (Quadratic Method)\tIN\n";
		#endif
		calculate_GeometricCoefficients(pIData,dim);
		calculate_LinearInterpolation(pIData,dim);
		for (int field=0; field<pIData->numFields; field++){
			calculate_Gradients(pIData,field);
			calculate_DerivativesError(pIData);
			calculate_QuadraticInterpolation(pIData,field);
		}
		#ifdef TRACKING_PROGRAM_STEPS
		cout << "TRACKING_PROGRAM_STEPS: Interpolation (Quadratic Method)\tIN\n";
		#endif
		break;

	case CONSERVATIVE:
		#ifdef TRACKING_PROGRAM_STEPS
		cout << "TRACKING_PROGRAM_STEPS: Interpolation (Conservative Method)\tIN\n";
		#endif
		//calculate_GeometricCoefficients(pIData,dim);
		//calculate_LinearInterpolation(pIData,dim);

		calculate_ConservativeInterpolation(pIData, dim);
	
		#ifdef TRACKING_PROGRAM_STEPS
		cout << "TRACKING_PROGRAM_STEPS: Interpolation (Conservative Method)\tIN\n";
		#endif
		cout << "parei motherfucker\n";
		STOP();

		break;
	default:
		throw Exception(__LINE__,__FILE__,"Interpolation method unknown. Exiting....");
	}
	finalize(pIData);
}


void initialize(InterpolationDataStruct* pIData){
	int dim = pIData->m1->getDim();
	pIData->theOctree = OctreeCreate2<iterall>(pIData->m2->beginall(dim),pIData->m2->endall(dim),dim);
	int nrows1 = M_numVertices(pIData->m1) + 1;	// New mesh (to)
	int nrows2 = M_numVertices(pIData->m2) + 1; // Old mesh (from)
	pIData->pNodeValue.allocateMemory(nrows2);
	pIData->pGrad.allocateMemory(nrows2,5);
	pIData->pGeomCoeff.allocateMemory(nrows1,dim+1);
	pIData->pInterpolatedVals.allocateMemory(nrows1);
}

void finalize(InterpolationDataStruct* pIData){
	pIData->pNodeValue.freeMemory();
	pIData->pInterpolatedVals.freeMemory();
	pIData->pGeomCoeff.freeMemory();
	pIData->pGrad.freeMemory();
	pIData->theOctree = 0;
}

double power(pPoint other, pPList  vertices_edge){

	pPoint P, Q;
	Vector* v;
	Vector* normal;
	//bool debug = true;

	pEntity vertex_P = (pEntity)PList_item(vertices_edge, 0);
	pEntity vertex_Q = (pEntity) PList_item(vertices_edge, 1);

	P =  V_point(vertex_P);
	Q =  V_point(vertex_Q);

	v = new Vector(P, Q);
	normal = v->normal_unit_pos_vector();

	double proj = (P_x(P) - P_x(other))*normal->getX() + (P_y(P) - P_y(other))*normal->getY();

	delete v;
	delete normal;

	return proj;

}

vector<pPoint> edge_intersection(pEntity edge1, pEntity edge2){

	pPList  vertices_edge2, vertices_edge1;
	double Power_P1, Power_P2, Power_Q1, Power_Q2, x, y;
	int numPoints = 1;
	pPoint A, B;
	vector<pPoint> intersect_points;
	bool _P1, _P2, _Q1, _Q2 = false;


	//list of vertices for each edge
	vertices_edge1 = E_vertices(edge1);
	vertices_edge2 = E_vertices(edge2);

	pPoint P1 = V_point((pEntity)PList_item(vertices_edge1, 0));
	pPoint P2 = V_point((pEntity)PList_item(vertices_edge1, 1));
	pPoint Q1 = V_point((pEntity)PList_item(vertices_edge2, 0));
	pPoint Q2 = V_point((pEntity)PList_item(vertices_edge2, 1));

	Power_P1 = power(Q1, vertices_edge1);
	Power_P2 = power(Q2, vertices_edge1);
	Power_Q1 = power(P1, vertices_edge2);
	Power_Q2 = power(P2, vertices_edge2);

	//number of zero powers 
	int count = 0;
	int* aux_x = new int[2];
	int* aux_y = new int[2];

	if(abs(Power_P1 - 0) < pow(10,-6)){
		_P1= true;
		count++;
	}
	if(abs(Power_P2 - 0) < pow(10,-6)){
		_P2 = true;
		count++;
	}
	if(abs(Power_Q1 - 0) < pow(10,-6)){
		_Q1 = true;
		count++;
	}
	if(abs(Power_Q2 - 0) < pow(10,-6)){
		_Q2 = true;
		count++;
	}

	A = P_new();
	B = P_new();

	switch (count){
		case 0:
				if(Power_P1*Power_P2 < 0 && Power_Q1*Power_Q2 < 0){
					x = P_x(P1) +(Power_Q1/(Power_Q1-Power_Q2))*(P_x(P2) - P_x(P1));
					y = P_y(P1) +(Power_Q1/(Power_Q1-Power_Q2))*(P_y(P2) - P_y(P1));

					P_setPos(A, x, y, 0);
				}

				break;
		case 1:	
				if (_P1 && Power_Q1*Power_Q2 < 0)
					P_setPos(A, P_x(Q1), P_y(Q1), 0);		
				else if (_P2 && Power_Q1*Power_Q2 < 0)
					P_setPos(A, P_x(Q2), P_y(Q2), 0);
				else if (_Q1 && Power_P1*Power_P2 < 0)
					P_setPos(A, P_x(P1), P_y(P1), 0);
				else if (_Q2 &&  Power_P1*Power_P2 < 0) 
					P_setPos(A, P_x(P2), P_y(P2), 0);
				else 
					numPoints = 0;

				break;
		case 2:	if((_P1 & _Q1) || (_P1 & _Q2))
					P_setPos(A, P_x(Q1), P_y(Q1), 0);			
				else if ((_P2 & _Q1) || (_P2 & _Q2))
					P_setPos(A, P_x(Q2), P_y(Q2), 0);
				else
					numPoints = 0;
				
				break;
		case 4:
				
				//calculando intervalo de intersecao em x
				aux_x[0] = max(min(P_x(P1), P_x(P2)), min(P_x(Q1), P_x(Q2)));
				aux_x[1] = min(max(P_x(P1), P_x(P2)), max(P_x(Q1), P_x(Q2)));

				
				if (aux_x[1] < aux_x[0]) {
				  numPoints = 0;
				  break;
				}
				else{
					//calculando intervalo de intersecao em y
					aux_y[0] = max(min(P_y(P1), P_y(P2)), min(P_y(Q1),  P_y(Q2)));
					aux_y[1] = min(max(P_y(P1), P_y(P2)), max(P_y(Q1), P_y(Q2)));
					
					if (aux_y[1] < aux_y[0]) {
				  		numPoints = 0;
				  		break;
					}
					else{
						
						P_setPos(A, aux_x[0], aux_y[0], 0);
						P_setPos(B, aux_x[1], aux_y[1], 0);

						if(P_x(A) == P_x(B) && P_y(A) == P_y(B))
							numPoints = 1;
						else
							numPoints = 2;
					}
				}
				break;
	}
	if(numPoints == 1){
		intersect_points.push_back(A);
	}
	else if (numPoints == 2){
		intersect_points.push_back(A);
		intersect_points.push_back(B);
	}

	return intersect_points;

	/*printf("\nPoint P1: (%lf, %lf)\n", P_x(P1),P_y(P1));
	printf("\nPoint P2: (%lf, %lf)\n", P_x(P2),P_y(P2));
	printf("\nPoint Q1: (%lf, %lf)\n", P_x(Q1), P_y(Q1));
	printf("\nPoint Q2: (%lf, %lf)\n", P_x(Q2), P_y(Q2));
	printf("\nPowers: %lf %lf %lf %lf\n", power_P1, power_P2, power_Q1, power_Q2);*/

}
